<?php defined( 'ABSPATH' ) || exit; ?>

<div class="rental_item ovabrw-error">
    <span class="ovabrw-message"></span>
</div>