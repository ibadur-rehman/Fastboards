<?php if ( !defined( 'ABSPATH' ) ) exit();

woocommerce_wp_text_input([
	'id' 			=> $this->get_meta_name( 'regul_price_hour' ),
	'class' 		=> 'ovabrw-input-required',
	'wrapper_class' => 'ovabrw-required',
	'label' 		=> esc_html__( 'Regular price / Hour', 'ova-brw' ),
	'placeholder' 	=> '',
	'desc_tip'    	=> 'true',
	'description' 	=> esc_html__( 'Regular price by hour', 'ova-brw' ),
	'data_type' 	=> 'price',
	'value' 		=> $this->get_meta_value( 'regul_price_hour' )
]);