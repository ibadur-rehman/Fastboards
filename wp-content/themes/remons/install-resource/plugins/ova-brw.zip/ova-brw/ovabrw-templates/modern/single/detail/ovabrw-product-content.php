<?php if ( !defined( 'ABSPATH' ) ) exit();

the_content();